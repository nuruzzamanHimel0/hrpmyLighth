<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
<?php 
	if(isset($_GET['dptId']) AND !empty($_GET['dptId']))
	{
		$id = base64_decode($_GET['dptId']);
		$dltReslt = $dpt->departmentDltbyId($id);
	}
	// else{
	// 	echo ""
	// }
?>
					<div class="col-md-9" style="margin-bottom: 20px;"> 
						<div class="bodySection">
								<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
									<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
										<p>Employee Type List </p>
								<?php 
									// if(!empty($dltReslt))
									// {
									// 	echo "<p class='mb-3'> ".$dltReslt["message"]." </p>";
									// }
								?>
									</div>

								</div>
							<div class="row"> 
								
								<div class="col-md-12 emplyCol8">
									<div class="emplyForm">
										
										<table id="example" class="table table-striped table-bordered " style="border: 1px solid #ddd;">
									        <thead>
									            <tr>
									                <th width="5%">No</th>
									                <th width="20%">Department</th>
									                <th width="15%">Action</th>
									                
									            </tr>
									        </thead>
									        <tbody>
							<?php 
								 $showDept = $dpt->showAllDepartment();
								 if($showDept != FALSE)
								 {	
								 	$i = 0;
								 	while ($values = $showDept->fetch_assoc())
								 	 {
									$i++;
							?>		        	
									            <tr>
									                <td><?php echo $i; ?></td>
									                <td><?php echo ucwords($values['deptname']); ?></td>
									                
									              	<td>
									              		<a href="editDepartment.php?id=<?php echo base64_encode($values['id']); ?>">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="?dptId=<?php echo base64_encode($values['id']); ?>"
									              			onclick="return confirm('Are you sure to want to Delete??');">
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="".>Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>

											</tbody>
									           
									             
						<?php } } ?>	


									           
									    </table>

		
									</div>
								<!-- 	.col-md-6 div end..................... -->
								</div>
								

						</div>
					</div> <!-- col-md-10 end.............. -->
					
					</form>
				</div>
			</div>
		</div>
		
		<?php 
	include("inc/footer.php");
?>