<?php
include("lib/Session.php");
Session::sess_start();

 Session::getlogout(); 

include_once("config/Config.php");
include_once("lib/Database.php");
include("helper/Formate.php");

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
header("Cache-Control: max-age=2592000");

	spl_autoload_register(function($class_name)
		{
		include("classes/".$class_name.".php");
	});
	

	// OBJECT CREATE...................
	$db = new Database();
	$fm = new Formate();
	$em = new Employee();
	$dpt = new Department();
	$deg = new Designation();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<link rel="stylesheet" href="css/fontawesome-all.min.css">
		<link rel="stylesheet" href="css/animate.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker3.css">
		<!-- data table Css Link Start....................... -->
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
		<!-- data table Css Link End....................... -->
		<link rel="stylesheet" href="style.css">
		<style type="text/css">
			a .notiicon{
					width: 28px;
					display: inline;
			}
			a .notiicon i {
				border: 0px !important;
				font-size: 17px !important;
				padding: 0px !important;
				margin: 0px !important;
				color: #fff;
			}
			a .notiicon .noti{
				font-size: 9px  !important;
				padding: 3px  !important;
				position: relative  !important;
				right: 4px ;
				top: -10px;
				background: #ef0707;
			}
			.dropdownNoti {
		position: absolute;
		will-change: transform;
		top: 10px !important;
		left: -1px !important;
		transform: translate3d(0px, 20px, 0px) !important;
		min-width: 15rem !important;
		padding: 0px !important;
		}
			.dropdownNoti i {
				margin: 0px;
				padding: 0px;
				position: absolute;
				top: -16px;
				left: -5px;
				color: #f3eeee;
			}
			.seeAll{
				border-top: 2px solid #ddd;
		text-align: center;
		background: #ddd;
		margin: 0px;
		color: #3338C2;
		font-size: 17px;
		font-weight: bold !important;
			}
			.seeAll:hover{
				background: #3338C2;
				color: #fff;
			}
			.dd_link {
		background: #ffeaea;
		border: 3px solid #e1cccc;
		padding: 4px 5px !important;
		}
			
		
		</style>
		
		<title>HR-Admin-MyLightHost</title>
	</head>
	<body>
		
		<div class="adminHeader fixed-top">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-3">
						<div class="headerLeft">
							<p>
								<a href="index.php">Admin Pannel</a>
							</p>
						</div>
					</div>
					<?php
						if(isset($_GET['action']) AND $_GET['action'] == 'logout')
						{
							Session::sess_destroy();
						}
					?>
					<div class="col-md-9">
						<div class="headerRight">
							
							<div class="row">
								<div class="col-md-3">
									<div class="logo">
										<h1>
										<img src="images/logo.png" >
										</h1>
									</div>
								</div>
								<div class="col-md-9">
									<div class="user">
										
										<?php
											$emplyId = Session::sess_get("emplyId");
											$emplyEmail = Session::sess_get("emplyEmail");
											$result = $em->emplyInfoByid($emplyId,$emplyEmail);
											if($result != FALSE)
											{
												while ($value = $result->fetch_assoc()) {
													
										?>
										
										<p>
											<!-- NOTIFICATION ICON START FOR NOTMAL EMPLOYEE.............................. -->
											<span class="dropdown" >

												<a href=""
													class='mr-2' id="dropdownNotiMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													<span  class="notiicon" style="">
														<i class="fas fa-bell align-center" style=""></i>
														<?php
															$notiCount = 0;
															$noti = $em->notiShowForEmployee($emplyId);
															if($noti != FALSE)
															{
																$result_noti = $noti->num_rows;
																$notiCount =  $notiCount+$result_noti;
																}
														?>
														<?php
															if($notiCount >0)
															{
														?>
														<span class="badge badge-light noti" style="">
															<?php echo $notiCount; ?>
														</span>
														<?php } ?>
														
														
													</span>
												</a>
												<!-- NOTIFICATION BARR................... -->
												<?php
													
													$ddResult = $em->notiShowForEmployee($emplyId);
													if($ddResult != FALSE)
													{
															while($ddValue = $ddResult->fetch_assoc())
														{
												
														
												?>
												<span class="dropdown-menu dropdownNoti" aria-labelledby="dropdownNotiMenu" >

													<!-- 			.............................Arrow icon..................... -->
													<i class="fas fa-sort-up"></i>
													
													<span>
														
								<a class="dropdown-item dd_link" href="empViewStatusProfile.php?emplyId=<?php echo base64_encode($ddValue['employeeId']); ?>&&emplySts=<?php echo base64_encode($ddValue['status']); ?>">
									<small>
									<b style="font-size:18px;" class="mr-2">**</b>
									<span style="font-style: italic;font-weight: bold;text-transform: uppercase;">
										<?php echo $ddValue['name']; ?>
										
									</span>
									your Profile
									</small><br>
									<small>Update Request is <b>Pending.</b></small>
								</a>
								
														
														<span class="dropdown-divider"></span>
														<a class="dropdown-item seeAll" href="empViewStatus.php?emplyId=<?php echo base64_encode($emplyId); ?>" style="border-top: 2px solid #ddd;text-align: center;">
															<small>See All</small>
														</a>
														
													</span>
													
													
												</span>
											<?php }} ?>	


											</span>
											
									<!-- NOTIFICATION ICON  FOR NOTMAL EMPLOYEE END.............................. -->			
											
											<img src="<?php echo $value['image'] ?>" width="35px"
											style="border:1px solid #fff;border-radius: 5px;" class="mr-1">
											<span class="mr-2">
												<?php echo ucwords($value['name']); ?>
											</span>
											<?php }} ?>
											<a href="?action=logout">
												<button class="btn btn-danger btn-sm">LogOut</button>
											</a>
											
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
		</div>