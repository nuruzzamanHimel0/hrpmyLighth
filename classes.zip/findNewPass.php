<?php include("classes/EmployeePassRecov.php"); ?>
<?php Session::getlogin();  ?>
<?php
$epr = new EmployeePassRecov();
if(isset($_GET['data']) AND !empty($_GET['data']))
{
$data = base64_decode($_GET['data']);
//echo $data;

// GET PASS CHECK................
  if(is_numeric($data))
  {
    // mobile NUMBER is here................
  }
  else
    {
    $gatePass = $epr->gatePassChecking($data);
    if($gatePass == FALSE)
    {
    header("Location: login.php");
    exit();
    }
  }

}
else
{
  header("Location: login.php");
  exit();
}
?>
<?php

// $sm = new Mailsend();
if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST["submit"]))
{
if(is_numeric($data))
{
  // mobile NUMBER is here................
}
else{
$passCheck = $epr->confirmPass($_POST,$data);
}

}
?>
<style type="text/css">
.findbg {
 
  
}
.findAcc {
  position: relative;
  margin: -30px auto;
  top: 60px;
  background: #ddd;
  padding: 68px 83px;
  border: 1px silid #ddd;
  border-radius: 4px;
  margin-bottom: 70px;
}
.findAccCard{
  width: 100% !important;
}
.card-footer a {
  width: 88px;
  height: 34px;
  font-weight: bold;
  margin: 3px;
}
</style>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="style.css">
    <title>HR-Admin</title>
  </head>
  <body>
    <div class="mainContent">
      <div class="headerSection">
        <div class="container header_con">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">
              <div class="logo">
                <img src="images/logo.png" alt="logo">
              </div>
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              
            </div>
          </nav>
        </div>
      </div>
      
      <div class="containerSection">
        
        <div class="container">
          <div class="findbg">
          <div class="row">
            
              <!-- <div class="col-md-10"> -->
                <div class="findAcc">
                  
                  <div class="card findAccCard ">

                    <div class="card-header font-weight-bold">Find Your Account</div>

                    <div class="card-body text-center">
                <?php 
                  if(isset($passCheck))
                  {
                    echo $passCheck['message'] ;
                  }
                ?> 
                      <div class="card-text text-left ">
                        <p class="">Please Inter your new password. A storng password is a combination of letter and persentage mark. It must be at least 6 characters long</p>
                        
            

                          <form class="form-inline" action="" method="post">


                            <div class="form-group mb-3" style="margin:2px auto;">
                              <label class="mr-2">
                                <small class="font-weight-bold" style="color: #808080;font-size: 16px;">New Password</small>
                              </label>

                              <div class="input-group" id="show_hide_new_password">
                                
                                <input type="password" class="form-control" id="inlineFormInputGroupUsername2" placeholder="New Password" name="newpass">

                                <div class="input-group-prepend">
                                  <div class="input-group-text">
                                      <a href=""><i class="fa fa-eye-slash" aria-hidden="true" style="color: #c89c9c;"></i></a>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                          

                          
                         
                            <div class="form-group" style="margin:2px auto;margin-left: 31px;">
                              <label class="mr-2">
                                <small class="font-weight-bold" style="color: #808080;font-size: 16px;">Confirm Password</small>
                              </label>

                              <div class="input-group" id="show_hidden_confirm_pass">
                                
                                <input type="password" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Confirm Password" name="confrmpass">
                                <div class="input-group-prepend">
                                  <div class="input-group-text">
                                      <a href=""><i class="fa fa-eye-slash" aria-hidden="true" style="color: #c89c9c;"></i></a>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                         
                      </div>
                      
                    </div>

                   
                       

                      <div class="card-footer text-right m-0 py-1">
                        <button class="btn btn-primary mr-1" name="submit" style="padding: 2px 9px; font-weight:bold;">Submit</button>
                        <button class="btn btn-light mr-1" style="border:1px solid #ddd; padding: 2px 9px;">
                           <a href="login.php" class="" >Cancel</a>
                        </button>
                    
                    </div>
                   
                  </form>
                  </div>
                   
                </div>
             <!--  </div> -->
            </div>
            
          </div>
        </div>
      </div>
      
      <div class="footerSection bg-light">
        <footer class="container">
          <div class="fcopy bg-light text-center"  >
            <div class="row">
              <div class="col-md-12">
                <div class="copy">
                  <p>Copyright © 2019 MyLightHost. All Rights Reserved.</p>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
    
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="custom.js"></script>
    <script src="js/modernizr-custom.js"></script>

 <!-- PASSWORD HIDDEN AND SHOW....................... -->
    <script type="text/javascript">
      
      $(document).ready(function() {
    $("#show_hide_new_password a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_new_password input').attr("type") == "text"){
            $('#show_hide_new_password input').attr('type', 'password');
            $('#show_hide_new_password i').addClass( "fa-eye-slash" );
            $('#show_hide_new_password i').removeClass( "fa-eye" );
        }else if($('#show_hide_new_password input').attr("type") == "password"){
            $('#show_hide_new_password input').attr('type', 'text');
            $('#show_hide_new_password i').removeClass( "fa-eye-slash" );
            $('#show_hide_new_password i').addClass( "fa-eye" );
        }
    });
});

          $(document).ready(function() {
    $("#show_hidden_confirm_pass a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hidden_confirm_pass input').attr("type") == "text"){
            $('#show_hidden_confirm_pass input').attr('type', 'password');
            $('#show_hidden_confirm_pass i').addClass( "fa-eye-slash" );
            $('#show_hidden_confirm_pass i').removeClass( "fa-eye" );
        }else if($('#show_hidden_confirm_pass input').attr("type") == "password"){
            $('#show_hidden_confirm_pass input').attr('type', 'text');
            $('#show_hidden_confirm_pass i').removeClass( "fa-eye-slash" );
            $('#show_hidden_confirm_pass i').addClass( "fa-eye" );
        }
    });
});

    </script>
     <!-- PASSWORD HIDDEN AND SHOW....................... -->
  </body>
</html>