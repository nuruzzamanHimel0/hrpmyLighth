 <?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
<style type="text/css">
	.nonoti {
	width: 100%;
	background: #ddd;
	min-height: 290px;
	border: 1px solid #ddd;
	border-radius: 10px;
}
	.nonoti h2 {
	text-transform: uppercase;
	font-size: 35px;
	width: 416px;
	text-align: center;
	margin: 0px auto;
	padding: 85px 0px;
	line-height: 48px;
	color: #cb1212;
	font-weight: bold;
}
</style>
<?php
	if(isset($_GET['emplyId']) AND !empty($_GET['emplyId']))
	{
		$emplyId = base64_decode($_GET['emplyId']);
		// echo $emplyId;
		// exit();

	}
	 else{
			echo "<script>window.location='index.php' </script>";
	 }
?>
<style type="text/css">
.viewpro{
	width: 94px;
	border: 2px solid #BAB8B8;
	background: #ddd;
	padding: 4px;
}

</style>
<div class="col-md-9" style="margin-bottom: 20px;">
	<div class="bodySection">
		<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
			<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px; text-align: center;">
				View Notifucation
			</div>
		</div>
		<?php
			// if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['submit']))
			// {
			// 	$addEmp = $em->addEmployee($_POST);
			// }
		?>
		<?php
			// if(!empty($addEmp))
			// {
			// 	echo $addEmp["message"];
			// }
		?>
		<div class="row mb-3">
			
			
			<div class="col-md-12 emplyCol8">
				<div class="emplyForm">
					
					<div class="viewStatus">
		<?php 
			$noNotiRes = $em->noNotificationByEmplyId($emplyId);
			if($noNotiRes != FALSE)
			{
		?>				
						<form action="" method="post" enctype="multipart/form-data">
							<table class="table table-bordered table-striped table-sm">
							<thead>
								<tr>
									<th scope="" width="5%">No</th>
									
									<th scope="" width="30%">Text</th>
									<th scope="" width="15%">View</th>
									<th scope="" width="15%">Status</th>
								</tr>
							</thead>
							<tbody>
					<?php
						if(isset($emplyId))
						{
							$getResult = $em->getnoti_employeProfileStatu($emplyId);
							if($getResult != FALSE)
							{
								
								while ($getValue = $getResult->fetch_assoc()) {
									
					?>		
								
									<tr>
										<th scope="" class="align-middle">
											<a href="index.php" class="btn ">
												1
											</a>
										</th>
									<!-- 	Notification message.......... -->
										<td class="align-middle">
										<?php 
											if($getValue['status'] == '0')
											{
										?>

												<p class="text-center">
													<i class="font-weight-bold"><?php echo ucwords($getValue['name']); ?></i> Your Profile Update request has been processed. Please Wait until it to be CLEARED.
												</p>
										<?php }else{ ?>	
												<p class="text-center">
													<i class="font-weight-bold"><?php echo ucwords($getValue['name']); ?></i> Your Profile Successfully Updated.
												</p>		
										<?php } ?>	
										</td>
									<?php 
										if($getValue['status'] == '0')
										{
									?>	
										<td class="align-middle">
											<a href="empViewStatusProfile.php?emplyId=
											<?php echo base64_encode($getValue['employeeId']); ?>&&emplySts=<?php echo base64_encode($getValue['status']); ?>">
												<p class="btn btn-primary btn-sm font-weight-bold f-1"> View</p>
											</a>
										</td>
									<?php }else{ ?>
										<td class="align-middle">
											<a href="#">
												<p class="btn btn-primary btn-sm font-weight-bold f-1 disabled" disabled> View</p>
											</a>
										</td>
									<?php } ?>	

										<td class="align-middle">
									<!-- PENDING ALART MESSAGE CHECK.................. -->		
									<?php 
										if($getValue['status'] == '0')
										{
									?>
										<p class="badge badge-pill badge-danger p-2">Pending</p>
									<?php	} else{?>
										<p class="badge badge-pill badge-success p-2">Success</p>
									<?php } ?>	
											
												
											
										</td>
									</tr>
						<?php }}} ?>
							</tbody>
						</table>
						</form>
						<!-- IF THERE HAVE NOT ANY NOTIFICATION YEAT.................. -->
				<?php }else{
				?>
						<div class="nonoti">
							<h2>There haven't any notification yeat</h2>
						</div>	
				<?php
				} ?>		
					</div>
					
				</div>
				<!-- 	.col-md-6 div end..................... -->
			</div>
			
		</div>
		</div> <!-- col-md-10 end.............. -->
		
	</form>
</div>
</div>
</div>
<?php
include("inc/footer.php");
?>