<?php 

	/**
	 * 
	 */
	class Department
	{
		
		private $db;
	 	private $fm;
	 	public function __construct()
	 	{
	 		$this->db = new Database();
	 		$this->fm = new Formate();
	 	}

	 	public function addDepartment($data)
 	{
 		$deptname = $this->fm->validation($data["deptname"]);
 		$deptname = mysqli_real_escape_string($this->db->conn,$deptname);

 		$ass_data = array("deptname"=>$deptname);

 		$dptRes = $this->db->insert("Department",$ass_data);

 		if($dptRes != FALSE)
		 	 	{
		 	 		
		 	 		 $response = array(
		            "type" => "success",
		            "message" => "
						<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
						 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
							Successfully Added Department.
						 </p>
					
						</div>
						
		            "
		        );
		         return $response;
		 	 	}
		 	 	else
		 	 	{
		 	 		 $response = array(
		            "type" => "success",
		            "message" => "
						<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
						 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
							Fail to add Department !!
						 </p>
					
						</div>
						
		            "
		        );
		         return $response;
		 	 	}

 	}

 	public function showAllDepartment()
 	{
 		$query = "SELECT * FROM Department ORDER BY id ASC ";
 		$dptReslt = $this->db->select($query);
 		if($dptReslt != FALSE)
 		{
 			return $dptReslt;
 		}
 		else{
 			return FALSE;
 		}
 	}

 	public function getDepartmentById($id)
 	{
 		$query = "SELECT * FROM Department WHERE id = '$id' ";
 		$dptReslt = $this->db->select($query);
 		if($dptReslt != FALSE)
 		{
 			return $dptReslt;
 		}
 		else{
 			return FALSE;
 		}
 	}

 	public function udtDepartmentById($data)
 	{
 		$id = $this->fm->validation($data["id"]);
 		$deptname = $this->fm->validation($data["deptname"]);

 		$id = mysqli_real_escape_string($this->db->conn,$id);
 		$deptname = mysqli_real_escape_string($this->db->conn,$deptname);

 		// echo "ID =".$id."<br>";
 		// echo "emplyType =".$emplyType."<br>";
 		// exit();

 		$ass_data = array("deptname"=>$deptname);
 		$udtRes = $this->db->update("Department",$ass_data," id = '$id' ");

 		if($udtRes != FALSE)
	 	 	{
	 	 		
	 	 		 $response = array(
	            "type" => "success",
	            "message" => "
					<div class='alert alert-success alert-dismissible fade show p-0 mb-2' role='alert'>
					 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
						Successfully Update Department.
					 </p>
				
					</div>
					
	            "
	        );
	         return $response;
	 	 	}
	 	 	else
	 	 	{
	 	 		 $response = array(
	            "type" => "success",
	            "message" => "
					<div class='alert alert-danger alert-dismissible fade show p-0 mb-2' role='alert'>
					 <p class='font-weight-bold text-secondary py-2 px-2 ml-1 mb-0'>
						Fail to Update Department !!
					 </p>
				
					</div>
					
	            "
	        );
	         return $response;
	 	 	}

 	}

 	public function departmentDltbyId($id)
 	{
 		$id = $this->fm->validation($id);
 		
 		$id = mysqli_real_escape_string($this->db->conn,$id);


 		$dltRes = $this->db->delete("Department"," id = '$id'");
 		if($dltRes != FALSE)
	 	 	{
	 	 		
	 	 		 return $dltRes;
	 	 	}
	 	 	else
	 	 	{
	 	 		return FALSE;
	 	 	}
 		
 	}




	}
?>