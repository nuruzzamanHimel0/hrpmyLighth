<?php 
	// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
include("includs/PHPMailer/src/Exception.php");
include("includs/PHPMailer/src/PHPMailer.php");
include("includs/PHPMailer/src/SMTP.php");
?>

<?php 
	
	class Mailsend 
	{
		private $mail;
		public function __construct()
		{
			$this->mail = new PHPMailer(ture); 
		}

		public function sendMail($to,$toName,$sub,$message)
		{


			
			// echo $to."<br>";
			// echo $sub."<br>";
			// echo $message."<br>";
			// exit();

					try {
		    //Server settings
		    $this->mail->SMTPDebug = 2;                                 // Enable verbose debug output
		    $this->mail->isSMTP();                                      // Set mailer to use SMTP
		    $this->mail->Host = 'apps.mylighthost.com';  // Specify main and backup SMTP servers
		    $this->mail->SMTPAuth = true;                               // Enable SMTP authentication
		    $this->mail->Username = 'hr@mylighthost.com';                 // SMTP username
		    $this->mail->Password = 'oiwRH1u3lQYz';                           // SMTP password
		    $this->mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
		    $this->mail->Port = 465;                                    // TCP port to connect to

		    //Recipients
		    $this->mail->setFrom('hr@mylighthost.com', 'Human Resourse');
		    $this->mail->addAddress($to, $toName);     // Add a recipient
		    //$mail->addAddress('rakibur@mylighthost.com');               // Name is optional
		   // $mail->addReplyTo('info@example.com', 'Information');
		   // $mail->addCC('cc@example.com');
		  //  $mail->addBCC('bcc@example.com');

		    //Attachments
		   // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
		   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
		    // body................................
		    
		    
		    $body = "

		<!DOCTYPE html>
		<html lang='en'>
		<head>
			<meta charset='UTF-8'>
			<title>PHP Mailer</title>


			<style type='text/css'>
				@import url('https://fonts.googleapis.com/css?family=Open+Sans');

			</style>
		</head>
		<body style='font-size: 16px;font-family: font-family: 'Open Sans', sans-serif;line-height: 17px;margin:0px;padding:0px;outline:0px;'>
			

			
			<div class='headersection template clear' style='width:90%; margin:0px auto;overflow:hidden;	background: #6eaff9;color: #fff;font-size: 19px;min-height: 86px;border: 1px solid #60a1cd;border-radius: 3px;'>

				<div class='logo' style='float:left;width: 47%;'>
					<img src='https://cdn.mylighthost.com/img/logo.png' style='	float: left;width: 60%;padding: 18px 18px;'>
				</div>
				

			</div>
			<div class='containersection template clear' style='width:90%; margin:0px auto;overflow:hidden;border: 1px dotted #c3ebef;min-height: 400px;background: url(http://cdn.mylighthost.com/hr/bg1.png)'>
				<div class='maintent clear' style='overflow:hidden;width:88%;margin: 0px auto;background: #fffafa;border-radius: 5px;margin-top: 22px;'>

					<div class='message' style='overflow:hidden;width: 100%;background: #C1F0FF;margin: 17px 0px;margin-bottom: 43px;'>

						<p style='font-size: 19px;text-transform: uppercase;display: block;width: 19%;margin: 19px auto;font-weight:bold;'>Message</p>
					</div>

					<div class='' style='overflow:hidden;line-height: 24px;text-align: justify;font-size: 16px;padding: 16px;'>
						<p>".$message."</p>
					</div>
					
				</div>
			</div>
			<div class='footersection template clear' style='width:90%; margin:0px auto;overflow:hidden;background: #6eaff9;border-radius: 3px;'>
				<div class='footer' style='width: 100%;padding: 18px 5px'>
					<p style='width: 50%;margin: 0px auto;font-size: 15px;color:black;'>Copyright ©".date('Y')."  MyLightHost. All rights reserved.</p>
				</div>
			</div>

			<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
			<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js'></script>
			<script src='temcustom.js'></script>
			<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js'></script>
		</body>
		</html>
		    ";
		    
		    
		    //Content
		    $this->mail->isHTML(true);                                  // Set email format to HTML
		    $this->mail->Subject = $sub ;
		    $this->mail->Body    = $body;
		    $this->mail->AltBody = strip_tags($body);

		    $this->mail->send();
		    echo 'Message has been sent';
		} catch (Exception $e) {
		    echo 'Message could not be sent. Mailer Error: ', $this->mail->ErrorInfo;
		}








			

		}
	}

?>