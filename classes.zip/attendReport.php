<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
		<div class="col-md-9" style="margin-bottom: 20px;">
			<div class="bodySection">
				
				<div class="row">
					
					<div class="col-md-12 emplyCol8">
						<div class="setAtten" >
							<div class="addTitle">
								<p>Report</p>
							</div>
							
							<div class="addFrom">
								
								<form>
									<div class="form-group row">
										<label for="inputPassword" class="" style="margin-right: 34px;">Department</label>
										<div class="col-sm-5">
											<select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
												<option selected>Choose...</option>
												<option value="1">Dept 1</option>
												<option value="2">Dept 2</option>
												<option value="3">Dept 3</option>
												<option value="3">Dept 4</option>
												<option value="3">Dept 5</option>
											</select>
										</div>
									</div>
									<div class="form-group row">
										<label for="staticEmail" class="" style="margin-right: 5px;">Month and Year</label>
										<div class="col-sm-5">
											<select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
												<option selected>Choose...</option>
												<option value="1">Current Day</option>
												<option value="2">Current Week</option>
												<option value="3">Full Month</option>
											</select>
										</div>
										
									</div>
									
									<div class="gobtn">
										<button type="submit" class="btn btn-primary">Go</button>
									</div>
									
								</form>
							</div>
							
							
						</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>
					<div class="col-md-12 emplyCol8">
						<div class="setAtten" style="background: none;border: none;" >
							<div class="emplyList">
								<p>Emplyee List</p>
							</div>
							
							<div class="" style="padding: 19px 10px;">
								<table class="table table-bordered table-striped">
									<thead class="thead-light">
										<tr>
											<th width="">Name</th>
											<th width="">Department</th>
											<th width="">Email </th>
											<th width="">Attend </th>
											<th width="">Absent </th>
											
									
											
										</tr>
									</thead>
									<tbody>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										<tr>
											<th scope="row">Md. Nuruzzaman</th>
											<td>Web Dev</td>
											<td>himel@gmail.com</td>
											<td>23 Days</td>
											<td>7 Days</td>
										
										
										</tr>
										
									</tbody>
								</table>
							</div>
							
							
						</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>
					
				</div>
				</div> <!-- col-md-10 end.............. -->
				
			</form>
		</div>
	</div>
</div>
<?php 
	include("inc/footer.php");
?>