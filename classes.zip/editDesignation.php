<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
<?php 
	if(isset($_GET['id']) AND !empty($_GET['id']))
	{
		$id = base64_decode($_GET['id']);
	}
	// else{
	// 	echo ""
	// }
?>
		<div class="col-md-9" style="margin-bottom: 20px;">
			<div class="bodySection">
				
				<div class="row">
					
					<div class="col-md-12 emplyCol8">
						<div class="setAtten" >
							<div class="addTitle">
								<p>Edit Emply Type</p>
							</div>

					<?php 
						if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['update']))
						{
							$udtdpt = $deg->udtDesignationById($_POST);
						}
					?>
					<?php 
						if(!empty($udtdpt))
						{
							echo $udtdpt["message"];
						}
					?>
					
							
							<div class="addNotice">

								
								<form action="" method="post">
					<?php 
						if(isset($id))
						{
							$getResult = $deg->getDesignationById($id);
							if($getResult != FALSE)
							{
								$degValue = $getResult->fetch_assoc();
					?>	
							
									<div class="form-group row">
										<label for="inputEmail3" class="col-sm-3 col-form-label">Emply Type</label>
									    <div class="col-sm-8">
									    	<input type="hidden" class="form-control" id="inputEmail3" value="<?php echo $degValue['id']; ?>" name="id">

									      <input type="text" class="form-control" id="inputEmail3" value="<?php echo ucwords($degValue['desigName']); ?>" name="desigName">
									    </div>
									</div>
					<?php }} ?>			
									<div class="gobtn" style="width: 60%; ">
										<button type="submit" class="btn btn-primary" name="update">Update</button>
									</div>
									
								</form>
							</div>
							
							
						</div>
						<!-- 	.col-md-6 div end..................... -->
					</div>
					<div class="col-md-12 emplyCol8">
							<div class="row mb-3 text-white " style="background: #7eb1ff; !important;width: 101%;height: 44px;margin-left: -5px;border: 1px solid #7eb1ff;border-radius: 5px;margin-top: 15px;">

									<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
										Designation List
									</div>

								</div>

								<div class="emplyForm">
										
										<table id="example" class="table table-striped table-bordered " style="border: 1px solid #ddd;">
									        <thead>
									            <tr>
									                <th width="5%">No</th>
									                <th width="20%">Department</th>
									                <!-- <th width="15%">Action</th> -->
									                
									            </tr>
									        </thead>
									        <tbody>
							<?php 
								 $showDeg = $deg->showAllDesignation();
								 if($showDeg != FALSE)
								 {	
								 	$i = 0;
								 	while ($values = $showDeg->fetch_assoc())
								 	 {
									$i++;
							?>		        	
									            <tr>
									                <td><?php echo $i; ?></td>
									                <td><?php echo ucwords($values['desigName']); ?></td>
									                
									              <!-- 	<td>
									              		<a href="editDesignation.php?id=<?php //echo base64_encode($values['id']); ?>">
									              			<button type="button" class="btn btn-primary" style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="?degtId=<?php //echo //base64_encode($values['id']); ?>"
									              			onclick="return confirm('Are you sure to want to Delete??');">
									              			<button type="button" class="btn btn-danger" style="padding: 5px 10px;" data-toggle="modal" data-target="".>Delete</button>

									              		</a>
									              		
									              		
									              	</td> -->
									            </tr>

											</tbody>
									           
									             
						<?php } } ?>	


									           
									    </table>

		
									</div>

								<!-- 	.col-md-6 div end..................... -->
								</div>
					
				</div>
				</div> <!-- col-md-10 end.............. -->
				
			</form>
		</div>
	</div>
</div>

<?php 
	include("inc/footer.php");
?>