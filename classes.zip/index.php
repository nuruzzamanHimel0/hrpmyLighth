<?php 
$page =  $_GET['a']; 


include("inc/header.php");
include("inc/aside.php");
	
switch ($page) {
		case 'addDepartment':
			include('source/addDepartment.php');
			break;
		case 'addNotice':
			include('source/addNorice.php');
			break;
		case 'logout':
			 Session::getlogout();
		default:
			include('source/homepage.php');
			break;
	}	

include("inc/footer.php");
?>