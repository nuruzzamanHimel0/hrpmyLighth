<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
					<div class="col-md-9" style="margin-bottom: 20px;"> 
						<div class="bodySection">
								<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
									<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
										Employee List
									</div>
								</div>
							<div class="row"> 
								
								<div class="col-md-12 emplyCol8">
									<div class="emplyForm" style="border: none;">
										
										<table id="" class="table table-striped table-bordered" style="border: 1px solid #ddd;margin-left: -15px;">
									        <thead  class="thead-dark">
									            <tr>
									                <th scope="col">No</th>
									                <th scope="col">Employee Name</th>
									                <th scope="col">Start Day</th>
									                <th scope="col">End Day</th>
									                <th scope="col">Status</th>
									                <th scope="col" width="25%">Action</th>
									            

									                
									            </tr>
									        </thead>
									        <tbody>
									            <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>12.02.19</td>
									                <td>14.02.19</td>
									                <td>
									                	<span class="bg-danger text-white p-1 font-weight-bold">Pending</span>
									            	</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary btn-sm " style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger btn-sm" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									             <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>12.02.19</td>
									                <td>14.02.19</td>
									                <td>
									                	<span class="bg-danger text-white p-1 font-weight-bold">Pending</span>
									            	</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary btn-sm " style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger btn-sm" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									             <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>12.02.19</td>
									                <td>14.02.19</td>
									                <td>
									                	<span class="bg-danger text-white p-1 font-weight-bold">Pending</span>
									            	</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary btn-sm " style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger btn-sm" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									             <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>12.02.19</td>
									                <td>14.02.19</td>
									                <td>
									                	<span class="bg-danger text-white p-1 font-weight-bold">Pending</span>
									            	</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary btn-sm " style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger btn-sm" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									             <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>12.02.19</td>
									                <td>14.02.19</td>
									                <td>
									                	<span class="bg-danger text-white p-1 font-weight-bold">Pending</span>
									            	</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary btn-sm " style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger btn-sm" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									             <tr>
									                <td scope="row">01</td>
									                <td>Md. Nuruzzaman</td>
									                <td>12.02.19</td>
									                <td>14.02.19</td>
									                <td>
									                	<span class="bg-danger text-white p-1 font-weight-bold">Pending</span>
									            	</td>
									                
									              	<td>
									              		<a href="#">
									              			<button type="button" class="btn btn-primary btn-sm " style="padding: 5px 10px;">Edit</button>
									              		</a>
									              		<a href="#" >
									              			<button type="button" class="btn btn-danger btn-sm" style="padding: 5px 10px;" data-toggle="modal" data-target="#exampleModal">Delete</button>

									              		</a>
									              		
									              		
									              	</td>
									            </tr>
									           
									           
									           
									           	           

									           
									    </table>	
		
									</div>
								<!-- 	.col-md-6 div end..................... -->
								</div>
								

						</div>
					</div> <!-- col-md-10 end.............. -->
					
					</form>
				</div>
			</div>
		</div>
		
		<?php 
	include("inc/footer.php");
?>