<div class="col-md-9" style="margin-bottom: 20px;"> 
						<div class="bodySection">
								<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
									<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
										DashBoard
									</div>
								</div>
							<div class="row"> 
								
								<div class="col-md-12 emplyCol8">
									<div class="wlcm">
										
										<p>Welcome Admin Pannel</p>



										
		
									</div>
								<!-- 	.col-md-6 div end..................... -->
								</div>
								

						</div>
					</div> <!-- col-md-10 end.............. -->
					
					</form>
				</div>
			</div>
		</div>
