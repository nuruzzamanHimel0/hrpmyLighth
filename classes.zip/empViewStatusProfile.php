<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>

<style type="text/css">
	.info {
	border-bottom: 2px solid #ddd;
	margin-bottom: 0px;
	padding-bottom: 0px;
	margin-bottom: 19px;
}
.info p {
	padding: 12px 0px;
	font-size: 18px;
	text-transform: capitalize;
	margin-bottom: 4px;
}
.viewimg {
	background: #daf4ed;
	border: 1px solid #b9b9b8;
	padding: 2px;
	width: 96px;
}
</style>
<?php
	if(isset($_GET['emplyId']) AND !empty($_GET['emplyId']) AND isset($_GET['emplySts']) AND !empty($_GET['emplySts']))
	{
		$employeeId = base64_decode($_GET['emplyId']);
		$status =  base64_decode($_GET['emplySts']);
		// echo $employeeId."<br>";
		// echo $status."<br>";
		// exit();
		
	}
	 else{
			echo "<script>window.location='index.php' </script>";
	 }
?>
<div class="col-md-9" style="margin-bottom: 20px;">
	<div class="bodySection">
		<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
			<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
				Add Employee
			</div>
		</div>
		<?php
			// if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['submit']))
			// {
			// 	$addEmp = $em->addEmployee($_POST);
			// }
		?>
		<?php
			// if(!empty($addEmp))
			// {
			// 	echo $addEmp["message"];
			// }
		?>
		<div class="row mb-3">
			
			<div class="col-md-6 emplyCol8">
				<div class="emplyForm">
					
					
					<div style="padding: 17px;min-height: 900px;border: 1px dotted #ddd;padding-top: 0px;">
			<?php 
				$empReslt = $em->getEmplyOldProfileInfo($employeeId);
				if($empReslt != FALSE)
				{
					$empValue = $empReslt->fetch_assoc();
			?>			
						<div class="row">
							<div class="col-md-12 info">
								<p class="text-center bg-info text-white font-weight-bold">Old Profile Info</p>
							</div>	
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Name
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($empValue['name']);  ?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Marrital Status
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Marrital Status" value="<?php 
						if( $empValue['maritalStatus'] == '1'){echo 'Married';}
						else if( $empValue['maritalStatus'] == '2'){echo 'Unmarried';}
						else if( $empValue['maritalStatus'] == '3'){echo 'Divorced';}
						else if( $empValue['maritalStatus'] == '4'){echo 'Widoweb';}
						else if( $empValue['maritalStatus'] == '5'){echo 'Separeted';}
					?>"  readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								NID
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo  $empValue['NID'];?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Education
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo  $empValue['eduName'];?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Present Address
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo $empValue['presentAddress'];?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Permanent Address
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo $empValue['permanentAddress'];?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Contuct
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo  $empValue['contuct'];?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Email
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo $empValue['email'];?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1" class="mr-5">
								Photo
							</label>
							<img src="<?php echo $empValue['image'];?> " width="80px" class="viewimg">
							
						</div>
				<?php } ?>		
						
					</div>
					
					
					<!-- </form> -->
					
				</div>
				<!-- 	.col-md-6 div end..................... -->
			</div>
			<div class="col-md-6">
				<div class="emplyForm">
					
					<div style="padding: 17px;min-height: 900px;border: 1px dotted #ddd;padding-top: 0px;">

				<?php 
				$udtReslt = $em->getEmplyUdtProfileInfo($employeeId,$status);
				if($udtReslt != FALSE)
				{
					$udtValue = $udtReslt->fetch_assoc();
					$check = array_intersect_assoc($empValue,$udtValue);

					// echo "<pre>";
					// print_r($check);
					// echo "</pre>";
					// exit();

			?>			
						<div class="row">
							<div class="col-md-12 info">
								<p class="text-center bg-info text-white font-weight-bold">Update Profile Info</p>
							</div>	
						</div>

						
						<div class="form-group">
							<label for="exampleInputEmail1">
								Name
							</label>
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" value="<?php echo ucwords($udtValue['name']);  ?>" readonly>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Marrital Status
							</label>
								
					<?php 
						if($check['maritalStatus'] == $udtValue['maritalStatus'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php 
						if( $udtValue['maritalStatus'] == '1'){echo 'Married';}
						else if( $udtValue['maritalStatus'] == '2'){echo 'Unmarried';}
						else if( $udtValue['maritalStatus'] == '3'){echo 'Divorced';}
						else if( $udtValue['maritalStatus'] == '4'){echo 'Widoweb';}
						else if( $udtValue['maritalStatus'] == '5'){echo 'Separeted';}
					?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php 
						if( $udtValue['maritalStatus'] == '1'){echo 'Married';}
						else if( $udtValue['maritalStatus'] == '2'){echo 'Unmarried';}
						else if( $udtValue['maritalStatus'] == '3'){echo 'Divorced';}
						else if( $udtValue['maritalStatus'] == '4'){echo 'Widoweb';}
						else if( $udtValue['maritalStatus'] == '5'){echo 'Separeted';}
					?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>		

						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								NID
							</label>
							
					<?php 
						if($check['NID'] == $udtValue['NID'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['NID']);  ?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['NID']);  ?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>	
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Education
							</label>
							
					<?php 
						if($check['eduName'] == $udtValue['eduName'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['eduName']);  ?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['eduName']);  ?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Present Address
							</label>
					<?php 
						if($check['presentAddress'] == $udtValue['presentAddress'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['presentAddress']);  ?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['presentAddress']);  ?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>	
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Permanent Address
							</label>
							<?php 
						if($check['permanentAddress'] == $udtValue['permanentAddress'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['permanentAddress']);  ?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['permanentAddress']);  ?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>	
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Contuct
							</label>
							
							<?php 
						if($check['contuct'] == $udtValue['contuct'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['contuct']);  ?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo ucwords($udtValue['contuct']);  ?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">
								Email
							</label>
									<?php 
						if($check['email'] == $udtValue['email'] )
						{
					?>
							
							<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo $udtValue['email'];  ?>" readonly>
					<?php }else{ ?>
							<input type="text" class="form-control fp is-valid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="cardNo" value="<?php echo $udtValue['email'];  ?>" readonly>
					<div class="valid-feedback">
				        Changed!
				      </div>
					<?php } ?>
							
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1" class="mr-5">
								Photo
							</label>
					<?php 
						if(!empty($udtValue['notiEmpImg']))
						{
					?>		
							<img src="<?php echo $udtValue['notiEmpImg'];?>" width="80px" class="viewimg">
					<?php }else{ ?>	
							<img src="images/no_images/no_image.png" width="80px" class="viewimg">
					<?php } ?>		

						</div>
						
					</div>
			<?php } ?>		
					
				</div>
			</div>
		</div>
		</div> <!-- col-md-10 end.............. -->
		
		
	</div>
</div>
</div>
<?php
include("inc/footer.php");
?>