<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
<div class="col-md-9" style="margin-bottom: 20px;">
	<div class="bodySection">
		<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
			<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
				Add Employee
			</div>
		</div>
	<?php 
		if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['submit']))
		{
			$addEmp = $em->addEmployee($_POST);
		}
	?>	
	<?php 
		if(!empty($addEmp))
		{
			echo $addEmp["message"];
		}
	?>
		<div class="row mb-3">
			
			<div class="col-md-6 emplyCol8">
				<div class="emplyForm">
					<!-- <div style="background: #B3B3FF;width: 100%;color: #6464B0;padding: 8px 5px;">
							<p style="margin: 0px 0px;">Personal Details</p>
					</div> -->

					<form action="#" method="POST" enctype="multipart/form-data">
						<div style="padding: 17px;min-height: 960px;">
							<div class="form-group">
								<label for="exampleInputEmail1">
									Employee ID
								</label>
								<input type="number" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Card No" name="cardNo" value="<?php echo Session::sess_get("cardNo"); ?>">
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Name
								</label>
								<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo Session::sess_get("name"); ?>">
								
							</div>
						<div class="form-group">
								<label for="exampleInputEmail1">
									Department
								</label>
								<select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="departmentId">
									<option selected>Choose...</option>
						<?php 
							$showDept = $em->showAllDept();
							if($showDept != FALSE)
							{
								while ($value = $showDept->fetch_assoc()) {
						?>			
								
									<option value="<?php echo $value['id']; ?>"
				 <?php
					if(Session::sess_get("departmentId") == $value['id']){echo "selected";}
				 ?>>
										<?php 
										echo $value['deptname']; 
										?>
									</option>
									
						<?php }} ?>			
								</select>
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Dath Of birth
								</label>
								<div class="input-group date">
									<div class="input-group-addon"  style="border: 1px solid #ddd;padding: 5px;">
										<i class="fa fa-calendar"></i>
									</div>
									<input type="date" class="datepicker form-control pull-right fp" id="datepicker" name="dateOfBirth" 
									value="<?php echo Session::sess_get("dateOfBirth"); ?>">
								</div>
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Father Name
								</label>
								<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Father Name" name="fathername" value="<?php echo Session::sess_get("fathername"); ?>">
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Mother Name
								</label>
								<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Mother Name" name="mothername" value="<?php echo Session::sess_get("mothername"); ?>">
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Marital Status
								</label>
								
								
								<select class="custom-select mr-sm-2 fp" id="inlineFormCustomSelect" name="maritalStatus">
				<option selected>Choose...</option>
			<option value="1" <?php
					if(Session::sess_get("maritalStatus") == "1"){echo "selected";}
				 ?>>Married</option>
				<option value="2" <?php
					if(Session::sess_get("maritalStatus") == "2"){echo "selected";}
				 ?>>Unmarried</option>
				<option value="3" <?php
					if(Session::sess_get("maritalStatus") == "3"){echo "selected";}
				 ?>>Divorced</option>
				<option value="4" <?php
					if(Session::sess_get("maritalStatus") == "4"){echo "selected";}
				 ?>>Widoweb</option>
				<option value="5" <?php
					if(Session::sess_get("maritalStatus") == "5"){echo "selected";}
				 ?>>Separeted</option>
									
								</select>
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Blood Group
								</label>
								
				<select class="custom-select mr-sm-2 fp" id="inlineFormCustomSelect" name="bloodGroup">
									<option selected>Choose...</option>
					<option value="1" 
					 <?php
					if(Session::sess_get("bloodGroup") == "1"){echo "selected";}
				 	?> >A+</option>
					<option value="2"
					 <?php
					if(Session::sess_get("bloodGroup") == "2"){echo "selected";}
				 	?>>O+</option>
					<option value="3"
					 <?php
					if(Session::sess_get("bloodGroup") == "3"){echo "selected";}
				 	?>>B+</option>
					<option value="4" 
					 <?php
					if(Session::sess_get("bloodGroup") == "4"){echo "selected";}
				 	?>>AB+</option>
					<option value="5" 
					 <?php
					if(Session::sess_get("bloodGroup") == "5"){echo "selected";}
				 	?> >A-</option>
					<option value="6" 
					 <?php
					if(Session::sess_get("bloodGroup") == "6"){echo "selected";}
				 	?>>O-</option>
					<option value="7" 
					 <?php
					if(Session::sess_get("bloodGroup") == "7"){echo "selected";}
				 	?> >B-</option>
					<option value="8" 
					 <?php
					if(Session::sess_get("bloodGroup") == "8"){echo "selected";}
				 	?> >AB-</option>
				</select>
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									NID
								</label>
								<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NID No" name="NID" value="<?php echo Session::sess_get("NID"); ?>">
								
							</div>
							
							<div class="form-group">
								<label for="exampleInputEmail1">
									Education
								</label>
								
								<select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="educationId">
									<option selected>Choose...</option>
						<?php 
							$showEdu = $em->showAllEdu();
							if($showEdu != FALSE)
							{
								while ($value = $showEdu->fetch_assoc()) 
								{
						?>			
								
									<option value="<?php echo $value['id']; ?>" 
				<?php
					if(Session::sess_get("educationId") == $value['id']){echo "selected";}
				 ?>>
										<?php 
										echo $value['eduName']; 
										?>
									</option>
									
						<?php }} ?>			
								</select>
								
							</div>
							
						</div>
						
						
						<!-- </form> -->
						
					</div>
					<!-- 	.col-md-6 div end..................... -->
				</div>
				<div class="col-md-6">
					<div class="emplyForm">
						<!-- <div style="background: #B3B3FF;width: 100%;color: #6464B0;padding: 8px 5px;">
								<p style="margin: 0px 0px;">Personal Details</p>
						</div> -->
						
						<!--
						<form action="#" method="POST"> -->
							<div style="padding: 17px; min-height: 960px;">
								<div class="form-group">
								<label for="exampleInputEmail1">
									Gender
								</label>
								
								
								<div class="form-check">
									<input class="form-check-input" type="radio" name="gender" id="inlineRadio1" value="1" 
									 <?php
					if(Session::sess_get("gender") == "1"){echo "checked";}
				 	?>
									>
									<label class="form-check-label" for="inlineRadio1">Male</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="2" 
												 <?php
					if(Session::sess_get("gender") == "2"){echo "checked";}
				 	?>>
									<label class="form-check-label" for="inlineRadio2">Female</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="3" 
												 <?php
					if(Session::sess_get("gender") == "3"){echo "checked";}
				 	?>>

									<label class="form-check-label" for="inlineRadio2">Other</label>
								</div>
								
							</div>
								<div class="form-group">
									<label for="exampleInputEmail1">
										Type Of Employee
									</label>
									
									<select class="custom-select mr-sm-2 fp" id="inlineFormCustomSelect" name="employTypeId">
										<option selected>Choose...</option>
						<?php 
							$showEtype = $em->showAllEmpType();
							if($showEtype != FALSE)
							{
								while ($value = $showEtype->fetch_assoc()) {
						?>			
							
							
										<option value="<?php echo $value['id']; ?>" 
				<?php
					if(Session::sess_get("employTypeId") == $value['id']){echo "selected";}
				 ?>>
										<?php 
										echo $value['emplyType']; 
										?>
									</option>
						<?php }}?>				
									</select>
									
								</div>

								<div class="form-group">
									<label for="exampleInputEmail1">
										Designation
									</label>
									
									<select class="custom-select mr-sm-2 fp" id="inlineFormCustomSelect" name="designationId">
										<option selected>Choose...</option>
						<?php 
							$showDesci = $em->showAllDegic();
							if($showDesci != FALSE)
							{
								while ($value = $showDesci->fetch_assoc()) {
						?>				
									<option value="<?php echo $value['id']; ?>"
				<?php
					if(Session::sess_get("designationId") == $value['id']){echo "selected";}
				 ?>>
										<?php 
										echo $value['desigName']; 
										?>
									</option>
										
						<?php }} ?>					
									</select>
									
								</div>
								
								<div class="form-group">
									<label for="exampleInputEmail1">
										Present Address
									</label>
									<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Present Address" name="presentAddress" 
									value="<?php echo Session::sess_get("presentAddress"); ?>">
									
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">
										Permanent Address
									</label>
									<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Permanent Address" name="permanentAddress"
									value="<?php echo Session::sess_get("permanentAddress"); ?>">

								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">
										Phone No
									</label>
									<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Education" name="contuct" 
									value="<?php echo Session::sess_get("contuct"); ?>">
									
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">
										Religion
									</label>
									
									<select class="custom-select mr-sm-2 fp" id="inlineFormCustomSelect" name="religion">
										<option selected>Choose...</option>
										<option value="1"  <?php
					if(Session::sess_get("religion") == "1"){echo "selected";}
				 	?>>Islam </option>
										<option value="2"  <?php
					if(Session::sess_get("religion") == "2"){echo "selected";}
				 	?>>Hinduism</option>
										<option value="3"  <?php
					if(Session::sess_get("religion") == "3"){echo "selected";}
				 	?>>Buddhists</option>
										<option value="4"  <?php
					if(Session::sess_get("religion") == "4"){echo "selected";}
				 	?>>Christians</option>
										<option value="5"  <?php
					if(Session::sess_get("religion") == "5"){echo "selected";}
				 	?>>Animists</option>
										
									</select>
									
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">
										Email
									</label>
									<input type="email" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email" name="email" value="<?php echo Session::sess_get("email"); ?>">
									
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">
										Password
									</label>
									
									
									<input type="password" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Password" name="password">
									
								</div>
							
								<div class="form-group ">
									<label for="exampleFormControlFile1" class="">
										Signature
									</label>
									
									<input type="file" class="form-control-file fp" id="exampleFormControlFile1" name="simage">
									
								</div>
								<div class="form-group ">
									<label for="exampleFormControlFile1" class="">
										Image
									</label>
									
									
									<input type="file" class="form-control-file fp" id="exampleFormControlFile1" name="pimage">
									
								</div>
								
							</div>
							<!-- .col-md-6 div end..................... -->
						</div>
					</div>
				</div>
				</div> <!-- col-md-10 end.............. -->
				<div class="submitBtn">
					<button type="submit" class="btn btn-primary" name="submit">Submit</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php
include("inc/footer.php");
?>