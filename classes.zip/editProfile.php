<?php include("inc/header.php"); ?>
<?php include("inc/aside.php"); ?>
<?php
	if(isset($_GET['eid']) AND !empty($_GET['eid']))
	{
		$id = base64_decode($_GET['eid']);
	}
	$udtTmpEmp = NULL;
	// else{
		// 	echo ""
	// }
?>
<div class="col-md-9" style="margin-bottom: 20px;">
	<div class="bodySection">
		<div class="row mb-3 text-white " style="background: #B0B0FC !important;width: 101%;height: 44px;margin-left: -5px;">
			<div class="col-md-12" style="font-weight: bold;margin: 8px 5px;font-size: 18px;">
				Add Employee
			</div>
		</div>
		<?php 
			$reqstPending = $em->requestPendingCheck($id);
			if($reqstPending != FALSE)
			{
				echo $reqstPending["pendingMsg"];
			}
		?>
		<?php
			if($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['update']))
			{
					$udtTmpEmp = $em->udtNotiEmployeeTable($_POST);
			}
			$_POST['update'] = NULL;
		?>

		
		
		<?php
			if(!empty($udtTmpEmp) )
			{
					echo $udtTmpEmp["message"];
			}

		?>
		<?php 
			
		// 	if(isset($udtTmpEmp['type']) AND $udtTmpEmp['type'] =='success')
		// {
		// 	echo "<meta http-equiv='refresh' content='0;URL=emplyList.php' > ";
		// }
		?>

		<div class="row mb-3">
			
			<div class="col-md-6 emplyCol8">
				<div class="emplyForm">
					<?php
						if(isset($id))
						{
							$getResult = $em->getEmployeeById($id);
							if($getResult != FALSE)
							{
								$etValue = $getResult->fetch_assoc();
					?>
					<form action="#" method="POST" enctype="multipart/form-data">
						<div style="padding: 17px;min-height: 500px;">
							<input type="hidden" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NID No" name="id" value="<?php echo $id ?>" >
							
							<div class="form-group">
								<label for="exampleInputEmail1">
									Marital Status
								</label>
								
								
								<select class="custom-select mr-sm-2 fp" id="inlineFormCustomSelect" name="maritalStatus">
									<option >Choose...</option>
									<option value="1"
										<?php
											if($etValue['maritalStatus'] == "1")
											{echo "selected='selected'";}
										?>
									>Married</option>
									<option value="2"
										<?php
											if($etValue['maritalStatus'] == "2"){echo "selected='selected'";}
										?>
									>Unmarried</option>
									<option value="3" <?php
											if($etValue['maritalStatus'] == "3"){echo "selected='selected'";}
									?>>Divorced</option>
									<option value="4" <?php
											if($etValue['maritalStatus'] == "4"){echo "selected='selected'";}
									?>>Widoweb</option>
									<option value="5" <?php
											if($etValue['maritalStatus'] == "5"){echo "selected='selected'";}
									?>>Separeted</option>
									
								</select>
								
							</div>
							
							<div class="form-group">
								<label for="exampleInputEmail1">
									NID
								</label>
								<input type="number" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NID No" name="NID" value="<?php echo ucwords($etValue['NID']); ?>" readonly >
								
							</div>
							
							<div class="form-group">
								<label for="exampleInputEmail1">
									Education
								</label>
								
								<select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="educationId">
									<option selected>Choose...</option>
									<?php
										$showEdu = $em->showAllEdu();
										if($showEdu != FALSE)
										{
											while ($value = $showEdu->fetch_assoc())
											{
									?>
									
									<option value="<?php echo $value['id']; ?>"
										<?php
											if($etValue['educationId'] == $value['id']){echo "selected='selected'";}
										?>>
										<?php
										echo $value['eduName'];
										?>
									</option>
									
									<?php }} ?>
								</select>
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Present Address
								</label>
								<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Present Address" name="presentAddress"
								value="<?php echo $etValue['presentAddress']; ?>">
								
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">
									Permanent Address
								</label>
								<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Permanent Address" name="permanentAddress"
								value="<?php echo $etValue['permanentAddress']; ?>">
							</div>
							
						</div>
						
						
						<!-- </form> -->
						
					</div>
					<!-- 	.col-md-6 div end..................... -->
				</div>
				<div class="col-md-6">
					<div class="emplyForm">
						
							<div style="padding: 17px; min-height: 500px;">
											
								<div class="form-group">
									<label for="exampleInputEmail1">
										Phone No
									</label>
									<input type="text" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Education" name="contuct"
									value="<?php echo $etValue['contuct']; ?>">
									
								</div>
								
								<div class="form-group">
									<label for="exampleInputEmail1">
										Email
									</label>
									<input type="email" class="form-control fp" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email" name="email" value="<?php echo $etValue['email']; ?>" >
									
								</div>
								
								
								<div class="form-group ">
									<label for="exampleFormControlFile1" class="">
										Image
									</label>
									
									
									<input type="file" class="form-control-file fp" id="exampleFormControlFile1" name="pimage">
									
								</div>
								
							</div>
							<!-- .col-md-6 div end..................... -->
						</div>
					</div>
		<?php 
			$reqstPending = $em->requestPendingCheck($id);
			if($reqstPending != FALSE)
			{
				
			
		?>
					<div class="submitBtn">
						<button type="submit" class="btn btn-primary" name="update" disabled>Update</button>
					</div>
		<?php }else{ ?>	
					<div class="submitBtn">
						<button type="submit" class="btn btn-primary" name="update" >Update</button>
					</div>	
		<?php } ?>					
				</div>
				
				</div> <!-- col-md-10 end.............. -->
				
			</form>
			<?php }} ?>
		</div>
	</div>
</div>
<?php
include("inc/footer.php");
?>